   <footer class="footer">
                    Copyright © VSMS 2020
                </footer>
